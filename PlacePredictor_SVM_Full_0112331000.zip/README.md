# PlacePredictor - SVM Module

Student: Muntasir Bin Kashem
ID: 0112331000
Branch: svm_0112331000

## Dataset
Placement_Data_Full_Class.csv

## Target
status

## Features Used
gender, ssc_p, ssc_b, hsc_p, hsc_b, hsc_s, degree_p, degree_t,
workex, etest_p, specialisation, mba_p

Dropped:
- salary (data leakage)
- sl_no (identifier)

## Evaluation Metrics
- Accuracy
- Precision
- Recall
- F1 Score

## Run
cd models
python svm_model.py
