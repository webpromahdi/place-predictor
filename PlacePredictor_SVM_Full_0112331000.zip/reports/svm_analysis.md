# SVM Analysis Report

## Team Member
Muntasir Bin Kashem (0112331000)

## Methodology
1. Remove salary and sl_no
2. Encode categorical features
3. Train/Test Split (80/20)
4. StandardScaler
5. SMOTE balancing
6. SVM (RBF Kernel)

## Results
Fill values generated from execution.

| Metric | Value |
|----------|----------|
| Accuracy | |
| Precision | |
| Recall | |
| F1 Score | |

## Interpretation

### Accuracy
Describe overall correctness.

### Precision
Describe reliability of positive placement predictions.

### Recall
Describe ability to identify placed students.

### F1 Score
Describe balance between precision and recall.

### Confusion Matrix Analysis
Discuss false positives and false negatives.

## Model Comparison

| Model | Accuracy | Precision | Recall | F1 |
|---------|---------|---------|---------|---------|
| Logistic Regression | | | | |
| Decision Tree | | | | |
| Random Forest | | | | |
| SVM | | | | |
| KNN | | | | |
| Naive Bayes | | | | |
